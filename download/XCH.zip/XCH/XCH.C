#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>

struct element_struct {
  char name[100];
  int num;
}elements_table[100];

int ERROR_CODE=-44;

int x_l=0,x_r=0,search_depth=0,element_num=0,molecule_num=0;
int maybe[101]={0};
int a[101][101]={{0}};
char equation[100]={0};

int check_int_exp(int alpha,int beta,int mode);
int legal_scan_couple();
int legal_scan(char ch);
int legal_scan_limited();
int legal_check();
int safe_get_num(FILE *stream,int n, ...);
int get_couple_pos(char raw[100],int pos);
int findSameElement(char raw[100]);
int safe_cvrt_num(char *raw);
int checkChar(char testchar);
int parser_molecule(char raw[100],int location_num,int times,int start_position,int end_position);
int parser_part(int start,int end,int flag);
int split_equation();
int check();
int xch_parser();
int parser_molecule(char *raw);
int parser_part(int start,int end);
int split_equation();
void xch_try(int x);
void display();
void display_detail();

int check_int_exp(int alpha,int beta,int mode)
{
  bool ans=false;
  int c=0;
  if (mode==1) ans=__builtin_sadd_overflow(alpha,beta,&c);
  if (mode==2) ans=__builtin_smul_overflow(alpha,beta,&c);
  if (ans==true)
  {
    printf("[ERROR] Illegal date\n");
    exit(ERROR_CODE);
  }
  return 0;
}

int legal_scan_couple()
{
  int i=0;
  for (i=0;i<=(int)(strlen(equation)-1);i++)
    if (equation[i]=='(')
      if (get_couple_pos(equation,i)==ERROR_CODE) return ERROR_CODE;
  return 0;
}

int legal_scan(char ch)
{
  int i=0,ans=0;
  for (i=0;i<=(int)(strlen(equation)-1);i++)
    if (equation[i]==ch) ans++;
  return ans;
}

int legal_scan_limited()
{
  int i=0;
  for (i=0;i<=(int)(strlen(equation)-1);i++)
    if (checkChar(equation[i])==ERROR_CODE)
      return ERROR_CODE;
  return 0;
}

int legal_check()
{
  if (legal_scan('=')!=1) return ERROR_CODE;
  if (legal_scan_limited()==ERROR_CODE) return ERROR_CODE;
  if (legal_scan_couple()==ERROR_CODE) return ERROR_CODE;
  return 0;
}

int safe_get_num(FILE *stream,int n, ...)
{
  int *targets[100]={NULL};
  int temp=0,num=0,count=-1,i=0;
  char raw[100]={0};
  char *last=NULL,*p=NULL;
  int ch=0;

  num=n;
  if ((n>100)||(n<=0)) return ERROR_CODE;
  va_list args;
  va_start(args,n);
  for (i=0;i<n;i++)
  {
    targets[i]=va_arg(args,int *);
  }
  va_end(args);
  fgets(raw,100,stream);
  if (raw[strlen(raw)-1]!='\n')
    while ((ch=fgetc(stream))!='\n'&&ch!=EOF);
  if (strcmp(raw,"")==0) return ERROR_CODE;
  p=strtok_r(raw," ",&last);
  while (p!=NULL)
  {
    temp=safe_cvrt_num(p);
    if (temp!=ERROR_CODE)
    {
      count++;
      *targets[count]=temp;
      if (count==num-1) break;
    }
    p=strtok_r(NULL," ",&last);
  }
  return count+1;
}

int get_couple_pos(char raw[100],int pos)
{
  int i=0,fake_stack=0;
  for (i=pos+1;i<=(int)(strlen(raw)-1);i++)
  {
    if (raw[i]=='(')
      fake_stack++;
    if (raw[i]==')')
    {
      if (fake_stack==0)
        return i;
      else fake_stack--;
    }
  }
  return ERROR_CODE;
}

int findSameElement(char raw[100])
{
  int i=0;
  for (i=1;i<=elements_table[0].num;i++)
    if (strcmp(elements_table[i].name,raw)==0)
      return elements_table[i].num;
  return ERROR_CODE;
}

int safe_cvrt_num(char *raw)
{
  char *endptr=NULL;
  long val=0;
  errno=0;
  val=strtol(raw,&endptr,10);
  if ((errno==ERANGE&&(val==LONG_MAX||val==LONG_MIN))||(errno!=0&&val==0)) return ERROR_CODE;
  if ((val>INT_MAX)||(val<INT_MIN)) return ERROR_CODE;
  if (endptr == raw) return ERROR_CODE;
  return (int) val;
}

int checkChar(char testchar)
{
  if ((testchar>='a')&&(testchar<='z'))
    return 1;
  if ((testchar>='A')&&(testchar<='Z'))
    return 2;
  if ((testchar>='0')&&(testchar<='9'))
    return 3;
  if ((testchar=='(')||(testchar==')'))
    return 4;
  return 0;
}

int parser_molecule(char raw[100],int location_num,int times,int start_position,int end_position)
{
  int pointer_element=-1,pointer_elements_num=-1,i=0,elements_num=1,j=0;
  char element[100]={0},elements_num_raw[100]={0};

  if (end_position-start_position+1>=100) return ERROR_CODE;

  i=start_position;
  while (i<=end_position)
  {
    if ((checkChar(raw[i])==2)||(raw[i]==0)||(checkChar(raw[i])==4))
    {
      if (strcmp(element,"")!=0)
      {
        if (strcmp(elements_num_raw,"")!=0)
        {
          if (safe_cvrt_num(elements_num_raw)!=ERROR_CODE)
            elements_num=safe_cvrt_num(elements_num_raw);
          else return ERROR_CODE;
        }
        if (findSameElement(element)==ERROR_CODE)
        {
          strcpy(elements_table[++elements_table[0].num].name,element);
          elements_table[elements_table[0].num].num=elements_table[0].num;
        }
        //conserve data
        // printf("%d %d\n",elements_num,times);
        check_int_exp(elements_num,times,2);
        a[findSameElement(element)][location_num]+=(elements_num*times);
      }
      //clean job
      elements_num=1;
      pointer_element=-1;
      pointer_elements_num=-1;
      memset(element,0,sizeof(element));
      memset(elements_num_raw,0,sizeof(elements_num_raw));
    }

    if ((checkChar(raw[i])==1)||(checkChar(raw[i])==2))
      element[++pointer_element]=raw[i];

    if (checkChar(raw[i])==3)
      elements_num_raw[++pointer_elements_num]=raw[i];

    if (raw[i]=='(')
    {
      if (get_couple_pos(raw,i)==ERROR_CODE)
        return ERROR_CODE;
      j=get_couple_pos(raw,i)+1;
      while (checkChar(raw[j])==3)
      {
        elements_num_raw[++pointer_elements_num]=raw[j];
        j++;
      }
      if (strcmp(elements_num_raw,"")!=0)
      {
        if (safe_cvrt_num(elements_num_raw)!=ERROR_CODE)
          elements_num=safe_cvrt_num(elements_num_raw);
        else return ERROR_CODE;
      }
      check_int_exp(elements_num,times,2);

      parser_molecule(raw,location_num,elements_num*times,i+1,get_couple_pos(raw,i));
      i=j-1;

      //clean job
      elements_num=1;
      pointer_element=-1;
      pointer_elements_num=-1;
      memset(element,0,sizeof(element));
      memset(elements_num_raw,0,sizeof(elements_num_raw));
    }
    i++;
  }
  return 0;
}

int parser_part(int start,int end,int flag)
{
  char raw[100]={0};
  char *last=NULL,*p=NULL;
  int sum=0;
  if (end<0) return ERROR_CODE;
  strncpy(raw,equation+start,(size_t) end);
  p=strtok_r(raw,"+",&last);
  while (p!=NULL)
  {
    sum++;
    parser_molecule(p,sum+flag,1,0,(int)(strlen(p)));
    p=strtok_r(NULL,"+",&last);
  }
  return sum;
}

int split_equation()
{
  int i=0,sum=0,position=0;
  for (i=0;i<(int) strlen(equation);i++)
    if (equation[i]=='=')
    {
      sum++;
      position=i;
    }
  if (sum==1) return position;
  return ERROR_CODE;
}

int xch_parser()
{
  if (legal_check()==ERROR_CODE)
  {
    printf("[ERROR] Illegal equation\n");
    return ERROR_CODE;
  }
  x_l=parser_part(0,split_equation(),0);
  x_r=parser_part(split_equation()+1,(int)(strlen(equation))-split_equation()-1,x_l);
  molecule_num=x_l+x_r;
  element_num=elements_table[0].num;
  return 0;
}

int check()
{
  int i=0,j=0,temp1=0,temp2=0;
  for (i=1;i<=element_num;i++)
  {
    temp1=0;temp2=0;
    for (j=1;j<=x_l;j++)
    {
      check_int_exp(a[i][j],maybe[j],2);
      check_int_exp(temp1,a[i][j]*maybe[j],1);
      temp1=temp1+a[i][j]*maybe[j];
    }
    for (j=x_l+1;j<=molecule_num;j++)
    {
      check_int_exp(a[i][j],maybe[j],2);
      check_int_exp(temp2,a[i][j]*maybe[j],1);
      temp2=temp2+a[i][j]*maybe[j];
    }
    //    temp2=temp2+a[i][j]*maybe[j];
    if (temp1!=temp2) return 0;
  }
  return 1;
}

void display()
{
  int i=0;
  printf("[OUTPUT] ");
  for (i=1;i<=x_l+x_r;i++)
     printf("%d ",maybe[i]);
  printf("\n");
}

void xch_try(int x)
{
  int i=0;
  if (x==x_l+x_r+1)
  {
    if (check()==1)
    {
      display();
      exit(0);
    }
  }
  else
  {
    for (i=1;i<=search_depth;i++)
    {
      maybe[x]=i;
      xch_try(x+1);
    }
  }
}

void display_detail()
{
  int i=0,j=0;
  printf("Here is the parser result of your equation.Check it right or not.\n");
  printf("If parser result is wrong.Please contact me <LEXUGEyky@outlook.com>\n");
  printf("element_num=%d element_num_left=%d element_num_right=%d molecule_num=%d\n"
  , element_num,x_l,x_r,molecule_num);
  printf("Parser found following elements:\n");
  for (i=1;i<=elements_table[0].num;i++)
    printf("%s ", elements_table[i].name);
  printf("\n");
  printf("Parser major result:\n");
  for (i=1;i<=element_num;i++)
  {
    printf("%s - ", elements_table[i].name);
    for (j=1;j<=molecule_num;j++)
      printf("%d ", a[i][j]);
    printf("\n");
  }
}

int main()
{
  int ch=0;
  elements_table[0].num=0;
  printf("XCH - Chemical Equation Balancer\n");
  printf("<> by LEXUGE\n");
  printf("Copyright (2017-2017) LEXUGE\n");
  printf("The software is using GPL(http://www.gnu.org/licenses/gpl.txt)\n");

  printf("[INPUT] Input the equation:\n");
  if (fgets(equation,100,stdin)==NULL)
  {
    printf("[ERROR] Please input the equation!\n");
    exit(0);
  }
  if (equation[(int)(strlen(equation)-1)]!='\n')
    while ((ch=fgetc(stdin))!='\n'&&ch!=EOF);
  else equation[(int)(strlen(equation)-1)]='\0';
  printf("[INPUT] Input the search depth:\n");
  if (safe_get_num(stdin,1,&search_depth)!=1)
  {
    printf("[ERROR] Input Again!\n");
    return ERROR_CODE;
  }
  xch_parser();
  xch_try(1);
  printf("[ERROR] No result.Please check your equation.\n");
  display_detail();
  return 0;
}
