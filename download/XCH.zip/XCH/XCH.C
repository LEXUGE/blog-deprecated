#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int x_l=0,x_r=0,n=0,n1=0,n2=0;
int sum[101]={0};
int maybe[101]={0};
int a[101][101]={0};

int check();
void xch_try(int x,int try_sum_l,int try_sum_r);
void display();

int check()
{
  int i=0,j=0,temp1=0,temp2=0;
  for (i=1;i<=n1;i++)
  {
    temp1=0;temp2=0;
    for (j=1;j<=x_l;j++)
      temp1=temp1+a[i][j]*maybe[j];
    for (j=x_l+1;j<=n2;j++)
      temp2=temp2+a[i][j]*maybe[j];
    if (temp1!=temp2) return 0;
  }
  return 1;
}

void display()
{
  int i=0;
  printf("------Output------\n");
  printf("各分子式系数分别为：\n");
  for (i=1;i<=x_l+x_r;i++)
  {
     printf("%d ",maybe[i]);
  }
  printf("\n");
}

void xch_try(int x,int try_sum_l,int try_sum_r)
{
  int i=0;
  if (x==x_l+x_r+1)
  {
     if ((try_sum_r==try_sum_l)&&(check()==1)) {display();exit(0);}
  }
  else
  {
    for (i=1;i<=n;i++)
    {
      maybe[x]=i;
      if (x<=x_l) xch_try(x+1,try_sum_l+sum[x]*i,try_sum_r);
      else xch_try(x+1,try_sum_l,try_sum_r+sum[x]*i);
    }
  }
}
int main()
{
  char s[101];
  char ch;
  int x=0,temp=0,i=0,j=0,r=0;
  printf("XCH - Chemical Equation Balancer\n");
  printf("By LEXUGE\n");
  printf("Copyright (2017-2017) LEXUGE\n");
  printf("The software is using GPL(http://www.gnu.org/licenses/gpl.txt)\n");
  printf("------Input------\n");
  printf("输入元素种类以及有几个分子式：\n");
  r=scanf("%d %d",&n1,&n2);
  if (r!=2) {printf("Input Error!\n");exit(0);}
  while((ch=getchar())!='\n'&&ch!=EOF);
  r=0;
  printf("输入每种元素包含的原子在方程式中各个分子式的个数：\n");
  for (i=1;i<=n1;i++)
  {
    r=0;
    for (j=1;j<=n2;j++)
    {
      r=0;
      r=scanf("%d",&a[i][j]);
      if(r!=1) {printf("Input Error!\n");exit(0);}
    }
    while((ch=getchar())!='\n'&&ch!=EOF);
  }
  printf("输入搜索最大值:\n");
  r=scanf("%d",&n);
  if(r!=1) {printf("Input Error!\n");exit(0);}
  while((ch=getchar())!='\n'&&ch!=EOF);
  r=0;
  printf("输入化学方程式的分子式量表达：\n");
  scanf("%s",s);
  while((ch=getchar())!='\n'&&ch!=EOF);
  for (i=0;i<=(int(strlen(s))-1);i++)
  {
    if ((s[i]>='0')&&(s[i]<='9'))
    {
      temp=temp*10+(s[i]-'0');
    }
    if (s[i]=='+')
    {
      x++;
      if (x_l!=0) sum[x+x_l]=temp;
      else sum[x]=temp;
      temp=0;
    }
    if (s[i]=='=')
    {
      x++;
      sum[x]=temp;
      temp=0;
      x_l=x;
      x=0;
    }
  }
  x++;
  sum[x+x_l]=temp;
  temp=0;
  x_r=x;
  xch_try(1,0,0);
  printf("------Output------\n");
  printf("无结果,建议检查输入是否正确\n");
  return 0;
}
