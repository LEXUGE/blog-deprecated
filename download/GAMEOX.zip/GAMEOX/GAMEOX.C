#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
char a[100][100];
int wid=0,turn=0,out=0;

void clrscr()
{
  printf("\033c");
}

int scan()
{
  int i=0,j=0,o=0,x=0;
  for (i=1;i<=wid;i++)
	for (j=1;j<=wid;j++)
	{
	  if (a[i][j]==' ') return 0;
	  if (a[i][j]=='X') x++;
	  if (a[i][j]=='O') o++;
	}
  clrscr();
  if (x>o) printf("X is winner!(press any key to continue)\n");
  if (x<o) printf("O is winner!(press any key to continue)\n");
  if (x==o) printf("tie!(press any key to continue)\n");
  getchar();
  getchar();
  return 1;
}
void fight(int x1,int y1)
{
  if (turn==0)
  {
	if (a[x1-1][y1-1]=='O') a[x1-1][y1-1]='X';
	if (a[x1-1][y1]=='O') a[x1-1][y1]='X';
	if (a[x1-1][y1+1]=='O') a[x1-1][y1+1]='X';
	if (a[x1][y1-1]=='O') a[x1][y1-1]='X';
	if (a[x1][y1+1]=='O') a[x1][y1+1]='X';
	if (a[x1+1][y1-1]=='O') a[x1+1][y1-1]='X';
	if (a[x1+1][y1]=='O') a[x1+1][y1]='X';
	if (a[x1+1][y1+1]=='O') a[x1+1][y1+1]='X';
  }
  else
  {
	if (a[x1-1][y1-1]=='X') a[x1-1][y1-1]='O';
	if (a[x1-1][y1]=='X') a[x1-1][y1]='O';
	if (a[x1-1][y1+1]=='X') a[x1-1][y1+1]='O';
	if (a[x1][y1-1]=='X') a[x1][y1-1]='O';
	if (a[x1][y1+1]=='X') a[x1][y1+1]='O';
	if (a[x1+1][y1-1]=='X') a[x1+1][y1-1]='O';
	if (a[x1+1][y1]=='X') a[x1+1][y1]='O';
	if (a[x1+1][y1+1]=='X') a[x1+1][y1+1]='O';
  }
}
void display(int n)
{
  int i=0,j=0;
  printf("\n");
  for (i=1;i<=n+1;i++)
  {
	if ((i==1)||(i==n+1))
	{
	  if (i==1) printf("%c%c%c%c",'=','=','=','=');
	  if (i==n+1) printf("%c  ",'=');
	}
	else printf("%c%c%c%c",'=','=','=','=');
  }
  printf("\n");
  for (i=1;i<=n*2-1;i++)
  {
	for (j=1;j<=n+1;j++)
	{
	  if (i%2==0)
	  {
		if ((j==1)||(j==n+1))
		{
		  if (j==1) printf("%c%c%c%c",'=','=','=','=');
		  if (j==n+1) printf("%c",'=');
		} else
		printf("%c%c%c%c",'=','=','=','=');
	  }
	  else
	  {
		if (j==n+1) printf("%c",'|'); else
		printf("%c %c ",'|',a[(i+1)/2][j]);
	  }
	}
	printf("\n");
  }
  for (i=1;i<=n+1;i++)
  {
	if ((i==1)||(i==n+1))
	{
	  if (i==1) printf("%c%c%c%c",'=','=','=','=');
	  if (i==n+1) printf("%c  ",'=');
	}
	else printf("%c%c%c%c",'=','=','=','=');
  }
  printf("\n");
}
void game()
{
  char ch;
  int x=0,y=0,t=0,r=0;
  while (1)
  {
	clrscr();
	display(wid);
	if (turn==0) printf("Now is X\n");
	else printf("Now is O\n");
	printf("please input two numbers of x,y:");
        r=scanf("%d %d",&x,&y);
        while((ch=getchar())!='\n'&&ch!=EOF)
	if ((x==0)&&(y==0)) {if ((turn+1)%2==0) turn=0; else turn=1;return;}
	if ((x==-3)&&(y==-3)) {out=1;return;}
	if ((a[x][y]==' ')&&((x>=1)&&(x<=wid))&&((y>=1)&&(y<=wid)))
	{
	  if ((turn==0)&&((a[x-1][y]=='X')||(a[x][y-1]=='X')||(a[x][y+1]=='X')||(a[x+1][y]=='X'))) {t=1;a[x][y]='X';fight(x,y);}
	  if ((turn==1)&&((a[x-1][y]=='O')||(a[x][y-1]=='O')||(a[x][y+1]=='O')||(a[x+1][y]=='O'))) {t=1;a[x][y]='O';fight(x,y);}
	  if (t==1) break;
	}
  }
  if (scan()==1) {out=1;return;}
  if ((turn+1)%2==0) turn=0;
  else turn=1;
}
void reset(int x)
{
  int i=0,j=0;
  for (i=1;i<=x;i++)
	for (j=1;j<=x;j++)
	  a[i][j]=' ';
  a[1][1]='O';
  a[1][x]='O';
  a[x][1]='X';
  a[x][x]='X';
}
void start()
{
  int r=0;
  char ch;
  printf("Please input a number of width:");
  r=scanf("%d",&wid);
  if ((wid<3)||(r!=1)) {printf("input again!\n");return;}
  r=0;
  while((ch=getchar())!='\n'&&ch!=EOF)
  reset(wid);
  clrscr();
  printf("Please input a number of first player(0:X/1:O):");
  r=scanf("%d",&turn);
  if (((turn!=0)&&(turn!=1))||(r!=1)) {printf("input again!\n");return;}
  while((ch=getchar())!='\n'&&ch!=EOF)
  display(wid);
  while (1)
  {
	game();
	if (out==1) break;
  }
}
int main()
{
  clrscr();
  start();
  return 0;
}
