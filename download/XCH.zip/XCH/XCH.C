/*
Copyright 2017 LEXUGE

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>

struct element_struct {
  char name[100];
  int num;
}elements_table[100];

int ERROR_CODE=-44;

int x_l=0,x_r=0,searching_range=0,element_num=0,molecule_num=0;
int maybe[101]={0};
int a[101][101]={{0}};
char equation[100]={0};
char raw_molecule[100]={0};

void about();
void input();
void wrong_exit(int mode);
int check_int_exp(int alpha,int beta,int mode);
int legal_scan_couple(char raw[100]);
int legal_scan(char ch);
int legal_scan_limited();
int legal_check();
int safe_get_num(FILE *stream,int n, ...);
int get_couple_pos(char raw[100],int pos,int mode);
int findSameElement(char raw[100]);
int safe_cvrt_num(char *raw);
int checkChar(char testchar);
int parser_molecule(int location_num,int times,int start_position,int end_position);
int parser_part(int start,int end,int flag);
int split_equation();
int check();
int xch_parser();
int parser_molecule(char *raw);
int parser_part(int start,int end);
int split_equation();
void xch_try(int x);
void display();
void display_detail();

void wrong_exit(int mode)
{
  if (mode==1) printf("[ERROR] String to number failed.\n");
  if (mode==2) printf("[ERROR] Unpaired parentheses.\n");
  if (mode==3) printf("[ERROR] end<0 or start<0.\n");
  if (mode==4) printf("[ERROR] Illegal start or end in 'parser_molecule'.\n");
  if (mode==5) printf("[ERROR] Illegal start or end in 'parser_part'.\n");
  if (mode==6) printf("[ERROR] Illegal date.\n");
  if (mode==7) printf("[ERROR] Please input the equation!\n");
  if (mode==8) printf("[ERROR] Illegal equation.\n");
  if (mode==9) printf("[ERROR] Input Again!\n");
  if (mode==10) printf("[ERROR] Illegal pos in 'get_couple_pos'\n");
  if (mode==11) printf("[ERROR] Illegal mode in 'get_couple_pos'\n");
  exit(ERROR_CODE);
}

int check_int_exp(int alpha,int beta,int mode)
{
  bool ans=false;
  int c=0;
  if (mode==1) ans=__builtin_sadd_overflow(alpha,beta,&c);
  if (mode==2) ans=__builtin_smul_overflow(alpha,beta,&c);
  if (ans==true) wrong_exit(6);
  return 0;
}

int legal_scan_couple(char raw[100])
{
  int i=0;
  for (i=0;i<=(int)(strlen(raw)-1);i++)
    if (raw[i]=='(')
      if (get_couple_pos(raw,i,1)==ERROR_CODE) return ERROR_CODE;

  for (i=(int)(strlen(raw)-1);i>=0;i--)
    if (raw[i]==')')
      if (get_couple_pos(raw,i,2)==ERROR_CODE) return ERROR_CODE;
  return 0;
}

int legal_scan(char ch)
{
  int i=0,ans=0;
  for (i=0;i<=(int)(strlen(equation)-1);i++)
    if (equation[i]==ch) ans++;
  return ans;
}

int legal_scan_limited()
{
  int i=0;
  for (i=0;i<=(int)(strlen(equation)-1);i++)
    if (checkChar(equation[i])==0)
      return ERROR_CODE;
  return 0;
}

int legal_check()
{
  if (legal_scan('=')!=1) return ERROR_CODE;
  if (legal_scan_limited()==ERROR_CODE) return ERROR_CODE;
  return 0;
}

int safe_get_num(FILE *stream,int n, ...)
{
  int *targets[100]={NULL};
  int temp=0,num=0,count=-1,i=0;
  char raw[100]={0};
  char *last=NULL,*p=NULL;
  int ch=0;

  num=n;
  if ((n>100)||(n<=0)) return ERROR_CODE;
  va_list args;
  va_start(args,n);
  for (i=0;i<n;i++)
  {
    targets[i]=va_arg(args,int *);
  }
  va_end(args);
  fgets(raw,100,stream);
  if (raw[strlen(raw)-1]!='\n')
    while ((ch=fgetc(stream))!='\n'&&ch!=EOF);
  if (strcmp(raw,"")==0) return ERROR_CODE;
  p=strtok_r(raw," ",&last);
  while (p!=NULL)
  {
    temp=safe_cvrt_num(p);
    if (temp!=ERROR_CODE)
    {
      count++;
      *targets[count]=temp;
      if (count==num-1) break;
    }
    p=strtok_r(NULL," ",&last);
  }
  return count+1;
}

int get_couple_pos(char raw[100],int pos,int mode)
{
  int i=0,fake_stack=0;

  if ((pos>=99)||(pos<0)) wrong_exit(10);
  if ((mode!=1)&&(mode!=2)) wrong_exit(11);
  if (mode==1)
  {
    for (i=pos+1;i<=(int)(strlen(raw)-1);i++)
    {
      if (raw[i]=='(')
        fake_stack++;
      if (raw[i]==')')
      {
        if (fake_stack==0)
          return i;
        else fake_stack--;
      }
    }
  }
  if (mode==2)
  {
    for (i=(int)(strlen(raw)-1);i>=pos+1;i--)
    {
      if (raw[i]==')')
        fake_stack++;
      if (raw[i]=='(')
      {
        if (fake_stack==0)
          return i;
        else fake_stack--;
      }
    }
  }
  return ERROR_CODE;
}

int findSameElement(char raw[100])
{
  int i=0;
  for (i=1;i<=elements_table[0].num;i++)
    if (strcmp(elements_table[i].name,raw)==0)
      return elements_table[i].num;
  return ERROR_CODE;
}

int safe_cvrt_num(char *raw)
{
  char *endptr=NULL;
  long val=0;
  errno=0;
  val=strtol(raw,&endptr,10);
  if ((errno==ERANGE&&(val==LONG_MAX||val==LONG_MIN))||(errno!=0&&val==0)) return ERROR_CODE;
  if ((val>INT_MAX)||(val<INT_MIN)) return ERROR_CODE;
  if (endptr == raw) return ERROR_CODE;
  return (int) val;
}

int checkChar(char testchar)
{
  if ((testchar>='a')&&(testchar<='z'))
    return 1;
  if ((testchar>='A')&&(testchar<='Z'))
    return 2;
  if ((testchar>='0')&&(testchar<='9'))
    return 3;
  if ((testchar=='(')||(testchar==')'))
    return 4;
  if ((testchar=='+')||(testchar=='='))
    return 5;
  return 0;
}

int parser_molecule(int location_num,int times,int start_position,int end_position)
{
  int pointer_element=-1,pointer_elements_num=-1,i=0,elements_num=1,j=0;
  char element[100]={0},elements_num_raw[100]={0};

  if ((end_position<0)||(start_position<0)) wrong_exit(4);
  if ((end_position>99)||(start_position>99)) wrong_exit(4);
  if (end_position<=start_position) wrong_exit(4);
  if (end_position-start_position+1>100) wrong_exit(4);

  i=start_position;
  while (i<=end_position)
  {
    if ((checkChar(raw_molecule[i])==2)||(raw_molecule[i]==0)||(checkChar(raw_molecule[i])==4))
    {
      if (strcmp(element,"")!=0)
      {
        if (strcmp(elements_num_raw,"")!=0)
        {
          if (safe_cvrt_num(elements_num_raw)!=ERROR_CODE)
            elements_num=safe_cvrt_num(elements_num_raw);
          else wrong_exit(1);
        }
        if (findSameElement(element)==ERROR_CODE)
        {
          strcpy(elements_table[++elements_table[0].num].name,element);
          elements_table[elements_table[0].num].num=elements_table[0].num;
        }
        //conserve data
        check_int_exp(elements_num,times,2);
        a[findSameElement(element)][location_num]+=(elements_num*times);
      }
      //clean job
      elements_num=1;
      pointer_element=-1;
      pointer_elements_num=-1;
      memset(element,0,sizeof(element));
      memset(elements_num_raw,0,sizeof(elements_num_raw));
    }

    if ((checkChar(raw_molecule[i])==1)||(checkChar(raw_molecule[i])==2))
      element[++pointer_element]=raw_molecule[i];

    if (checkChar(raw_molecule[i])==3)
      elements_num_raw[++pointer_elements_num]=raw_molecule[i];

    if (raw_molecule[i]=='(')
    {
      if (get_couple_pos(raw_molecule,i,1)==ERROR_CODE)
        wrong_exit(2);
      j=get_couple_pos(raw_molecule,i,1)+1;
      while (checkChar(raw_molecule[j])==3)
      {
        elements_num_raw[++pointer_elements_num]=raw_molecule[j];
        j++;
      }
      if (strcmp(elements_num_raw,"")!=0)
      {
        if (safe_cvrt_num(elements_num_raw)!=ERROR_CODE)
          elements_num=safe_cvrt_num(elements_num_raw);
        else wrong_exit(1);
      }
      check_int_exp(elements_num,times,2);

      parser_molecule(location_num,elements_num*times,i+1,get_couple_pos(raw_molecule,i,1));
      i=j-1;

      //clean job
      elements_num=1;
      pointer_element=-1;
      pointer_elements_num=-1;
      memset(element,0,sizeof(element));
      memset(elements_num_raw,0,sizeof(elements_num_raw));
    }
    i++;
  }
  return 0;
}

int parser_part(int start,int end,int flag)
{
  char raw[100]={0};
  char *last=NULL,*p=NULL;
  int sum=0;

  if ((end<0)||(start<0)) wrong_exit(3);
  if (start+end>=99) wrong_exit(5);

  strncpy(raw,equation+start,(size_t) end);
  p=strtok_r(raw,"+",&last);
  while (p!=NULL)
  {
    sum++;
    if (legal_scan_couple(p)==ERROR_CODE) wrong_exit(8);
    strncpy(raw_molecule,p,strlen(p));
    parser_molecule(sum+flag,1,0,(int)strlen(p));
    memset(raw_molecule,0,sizeof(raw_molecule));
    p=strtok_r(NULL,"+",&last);
  }
  memset(raw_molecule,0,sizeof(raw_molecule));
  return sum;
}

int split_equation()
{
  int i=0,sum=0,position=0;
  for (i=0;i<(int) strlen(equation);i++)
    if (equation[i]=='=')
    {
      sum++;
      position=i;
    }
  if (sum==1) return position;
  return ERROR_CODE;
}

int xch_parser()
{
  if (legal_check()==ERROR_CODE) wrong_exit(8);
  x_l=parser_part(0,split_equation(),0);
  x_r=parser_part(split_equation()+1,(int)(strlen(equation))-split_equation()-1,x_l);
  molecule_num=x_l+x_r;
  element_num=elements_table[0].num;
  return 0;
}

int check()
{
  int i=0,j=0,temp1=0,temp2=0;
  for (i=1;i<=element_num;i++)
  {
    temp1=0;temp2=0;
    for (j=1;j<=x_l;j++)
    {
      check_int_exp(a[i][j],maybe[j],2);
      check_int_exp(temp1,a[i][j]*maybe[j],1);
      temp1=temp1+a[i][j]*maybe[j];
    }
    for (j=x_l+1;j<=molecule_num;j++)
    {
      check_int_exp(a[i][j],maybe[j],2);
      check_int_exp(temp2,a[i][j]*maybe[j],1);
      temp2=temp2+a[i][j]*maybe[j];
    }
    if (temp1!=temp2) return 0;
  }
  return 1;
}

void display()
{
  int i=0;
  printf("[OUTPUT] ");
  for (i=1;i<=x_l+x_r;i++)
     printf("%d ",maybe[i]);
  printf("\n");
}

void xch_try(int x)
{
  int i=0;
  if (x==x_l+x_r+1)
  {
    if (check()==1)
    {
      display();
      exit(0);
    }
  }
  else
  {
    for (i=1;i<=searching_range;i++)
    {
      maybe[x]=i;
      xch_try(x+1);
    }
  }
}

void display_detail()
{
  int i=0,j=0;
  printf("Here is the parse of your equation.Check it.\n");
  printf("If you have any question, please contact me <LEXUGEyky@outlook.com>\n\n");
  printf("Result infos:\n");
  printf("element_num=%d\nelement_num_left=%d\nelement_num_right=%d\nmolecule_num=%d\n\n"
  , element_num,x_l,x_r,molecule_num);
  printf("Parser found the following elements:\n");
  for (i=1;i<=elements_table[0].num;i++)
    printf("%s ", elements_table[i].name);
  printf("\n\n");
  printf("Result:\n");
  for (i=1;i<=element_num;i++)
  {
    printf("%s - ", elements_table[i].name);
    for (j=1;j<=molecule_num;j++)
      printf("%d ", a[i][j]);
    printf("\n");
  }
}

void about()
{
  printf("XCH - Chemical Equation Balancer\n");
  printf("<> by LEXUGE <LEXUGEyky@outlook.com>\n");
  printf("Copyright (C) 2017 LEXUGE\n");
  printf("License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>\n\n");
}

void input()
{
  int ch=0;
  printf("[INPUT] Input the equation:\n");
  if (fgets(equation,100,stdin)==NULL) wrong_exit(7);
  if (equation[(int)(strlen(equation)-1)]!='\n')
    while ((ch=fgetc(stdin))!='\n'&&ch!=EOF);
  else equation[(int)(strlen(equation)-1)]='\0';

  printf("[INPUT] Input the searching range:\n");
  if (safe_get_num(stdin,1,&searching_range)!=1) wrong_exit(9);
}

int main()
{
  elements_table[0].num=0;
  about();
  input();
  xch_parser();
  xch_try(1);
  printf("[ERROR] No result.Please check your equation.\n");
  display_detail();
  return 0;
}
