#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int x=1,y=1;
char a[24][81];

void fr();
void fw();
int non(char ch);
int key(char ch);
int ctrkey(char ch);
int cursor(char ch);
void prin(int n);
void init();

void init()
{
  int i=0,j=0;
  for (i=1;i<=23;i++)
    for (j=1;j<=80;j++)
      a[i][j]=32;
}

void gotoxy(int x,int y)
{
   printf("%c[%d;%df",0x1B,y,x);
}

void clrscr()
{
  printf("\033c");
}

int getch()
{
    char ch;
    system("stty -echo -icanon");
    ch=getchar();
    system("stty echo icanon");
    return ch;
}

void fr()
{
  FILE *fp;
  int i,j;
  char ch;
  char fpath[10];
  memset(fpath,0,sizeof(fpath));
  clrscr();
  printf("[OPEN] Please input the file path:");
  scanf("%s",&fpath);
  if ((fp=fopen(fpath,"r"))==NULL)
  {
	printf("Can't open the file!");
	getch();
	return;
  }
  i=1;
  j=0;
  while ((ch=getc(fp))!=EOF)
  {
	if ((j==80)&&(i<=23)) {i++;j=0;}
	if (ch!='\n')
	{
	  j++;
	  a[i][j]=ch;
	}
  }
  fclose(fp);
  printf("Read the file successful!");
  getch();
  getch();
  clrscr();
  return;
}
void fw()
{
  FILE *fp;
  char fpath[10];
  int i=0,j=0;
  memset(fpath,0,sizeof(fpath));
  clrscr();
  printf("[SAVE] Please input the file path:");
  scanf("%s",&fpath);
  if ((fp=fopen(fpath,"w"))==NULL)
  {
	printf("Can't open file!");
	getch();
	clrscr();
	exit(0);
  }
  for (i=1;i<=23;i++)
  {
	for (j=1;j<=80;j++)
	  putc(a[i][j],fp);
	putc('\n',fp);
  }
  fclose(fp);
  printf("Write the file successful!");
  getch();
  clrscr();
  exit(0);
}
int key(char ch)
{
  a[x][y]=ch;
  if (y<80) y=y+1;
  else
  if ((y==80)&&(x<23)) {x=x+1;y=1;}
  prin(1);
  return 1;
}
int ctrkey(char ch)
{
  if (ch==10)
  {
	if (x<23)
	{
	  x=x+1;
	  y=1;
	}
	prin(2);
	return 1;
  }
  if (ch==127)
  {
        
	if (y>1)
	{
	  a[x][y-1]=' ';
	  if (y>1) y=y-1;
	  prin(1);
	  return 1;
	}
	else
	if ((y==1)&&(x>1)) {x=x-1;y=80;a[x][y]=' ';prin(1);}
  }
  /*if (ch==127)
  {
	a[x][y]=' ';
	prin(1);
	return 1;
  }*/
  if (ch==23)
  {
	fw();
	return 1;
  }
  if (ch==18)
  {
	fr();
        
	prin(1);
	return 1;
  }
  return 0;
}
int cursor(char ch)
{
  if (ch==27)
  {
  ch=getch();
  if (ch==91)
  {
  ch=getch();
  if (ch=='A')
  {
	if (x>1) x=x-1;
	prin(2);
	return 1;
  }
  if (ch=='B')
  {
	if (x<23) x=x+1;
	prin(2);
	return 1;
  }
  if (ch=='D')
  {
	if (y>1) y=y-1;
	else
	if ((y==1)&&(x>1)) {x=x-1;y=80;prin(2);}
	prin(2);
	return 1;
  }
  if (ch=='C')
  {
	if (y<80) y=y+1; else
	if ((y==80)&&(x<23)) {x=x+1;y=1;}
	prin(2);
	return 1;
  }
  }
  }
  if (ch==27)  return 2;
  return 0;
}
void prin(int n)
{
  int i=0,j=0;

  if (n==1)
  {
	clrscr();
	for (i=1;i<=23;i++)
	{
	  for (j=1;j<=80;j++)
		
		printf("%c",a[i][j]);
	}
	gotoxy(61,24);
	printf("Powered by LEXUGE");
  }
  gotoxy(5,24);
  printf("X:%d Y:%d ",x,y);
  gotoxy(y,x);
}
int main()
{
   char ch;
   int n=0,key1=0;
   init();
   prin(1);
   while (1)
   {
	 ch=getch();
	 key1=ch;
	 n=cursor(ch);
	 if (n==2) {clrscr();return 0;}
	 if (n==0)
	 n=ctrkey(ch);
	 if ((key1>=32)&&(key1<=126))
	 n=key(ch);
   }
   return 0;
}
