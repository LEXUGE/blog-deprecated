#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int width=80;
int height=300;
int dstart=1;
int x=1,y=1;
char a[301][81];

void fr();
void fw();
int non(char ch);
int key(char ch);
int ctrkey(char ch);
int cursor(char ch);
void prin(int n);
void init();

void init()
{
  int i=0,j=0;
  for (i=1;i<=height;i++)
    for (j=1;j<=width;j++)
      a[i][j]=32;
}

void gotoxy(int x,int y)
{
   printf("%c[%d;%df",0x1B,y,x);
}

void clrscr()
{
  printf("\033c");
}

int getch()
{
    char ch;
    system("stty -echo -icanon");
    ch=getchar();
    system("stty echo icanon");
    return ch;
}

void fr()
{
  FILE *fp;
  int c=0,r=0,flag=0;
  int i,j;
  char ch;
  char fpath[100];
  init();
  memset(fpath,0,sizeof(fpath));
  clrscr();
  printf("[OPEN] Please input a number to decryption:");
  r=scanf("%d",&c);
  while((ch=getchar())!='\n'&&ch!=EOF);
  ch=0;
  if ((r!=1)) {printf("Error!\n");getch();getch();clrscr();return;}
  r=0;

  printf("[OPEN] Please input the file path:");
  scanf("%s",fpath);
  if ((fp=fopen(fpath,"r"))==NULL)
  {
  printf("Can't open the file!");
  getch();
  getch();
  clrscr();
  return;
  }
  i=1;
  j=0;
  while ((ch=getc(fp))!=EOF)
  {
  flag=0;
  if (i>height) break;
  if ((j==width)&&(i<=height))
  {
    i++;
    j=0;
    flag=1;
  }
  if (ch!='\n')
  {
    j++;
    a[i][j]=ch+c;
  }
  if ((ch=='\n')&&(flag==0))
  {
    i++;
    j=0;
  }
  }
  fclose(fp);
  printf("Read the file successful!");
  getch();
  getch();
  clrscr();
  return;
}
void fw()
{
  FILE *fp;
  char fpath[100];
  int i=0,j=0;
  int c=0,r=0;
  char ch=0;
  memset(fpath,0,sizeof(fpath));
  clrscr();
  printf("[SAVE] Please input a number to encrypt:");
  r=scanf("%d",&c);
  while((ch=getchar())!='\n'&&ch!=EOF);
  ch=0;
  if ((r!=1)) {printf("Error!\n");getch();getch();clrscr();return;}
  r=0;
  printf("[SAVE] Please input the file path:");
  scanf("%s",fpath);
  if ((fp=fopen(fpath,"w"))==NULL)
  {
  printf("Can't open file!");
  getch();
  getch();
  clrscr();
  exit(0);
  }
  for (i=1;i<=height;i++)
  {
  for (j=1;j<=width;j++)
    putc(a[i][j]-c,fp);
  putc('\n',fp);
  }
  fclose(fp);
  printf("Write the file successful!");
  getch();
  getch();
  clrscr();
  exit(0);
}
int key(char ch)
{
  a[x][y]=ch;
  if (y<width) y=y+1;
  else
  if ((y==width)&&(x<height)) {x=x+1;y=1;}
  if (x>(22+dstart)) dstart++;
  prin(1);
  return 1;
}
int ctrkey(char ch)
{
  if (ch==10)
  {
  if (x<height)
  {
    x=x+1;
    y=1;
  }
  if (x>(22+dstart)) dstart++;
  prin(2);
  return 1;
  }
  if (ch==127)
  {

  if (y>1)
  {
    a[x][y-1]=' ';
    if (y>1) y=y-1;
    prin(1);
    return 1;
  }
  else
  if ((y==1)&&(x>1)) {x=x-1;y=width;a[x][y]=' ';if (x<(dstart)) dstart--;prin(1);}
  }
  /*if (ch==127)
  {
  a[x][y]=' ';
  prin(1);
  return 1;
  }*/
  if (ch==23)
  {
  fw();
  return 1;
  }
  if (ch==18)
  {
  fr();

  prin(1);
  return 1;
  }
  return 0;
}
int cursor(char ch)
{
  if (ch==27)
  {
  ch=getch();
  if (ch==91)
  {
  ch=getch();
  if (ch=='A')
  {
  if (x>1) x=x-1;
  if (x<(dstart)) dstart--;
  prin(1);
  return 1;
  }
  if (ch=='B')
  {
  if (x<height) x=x+1;
  if (x>(22+dstart)) dstart++;
  prin(1);
  return 1;
  }
  if (ch=='D')
  {
  if (y>1) y=y-1;
  else
  if ((y==1)&&(x>1)) {x=x-1;y=width;if (x<(dstart)) dstart--;prin(2);}
  prin(1);
  return 1;
  }
  if (ch=='C')
  {
  if (y<width) y=y+1; else
  if ((y==width)&&(x<height)) {x=x+1;y=1;if (x>(22+dstart)) dstart++;}
  prin(1);
  return 1;
  }
  }
  }
  if (ch==27)  return 2;
  return 0;
}
void prin(int n)
{
  int i=0,j=0;

  if (n==1)
  {
  clrscr();
  for (i=dstart;i<=dstart+22;i++)
  {
    for (j=1;j<=width;j++)

    printf("%c",a[i][j]);
    printf("\n");
  }
  gotoxy(61,24);
  printf("Powered by LEXUGE");
  }
  gotoxy(5,24);
  printf("X:%d Y:%d ",x,y);
  gotoxy(y,(x-dstart+1));
}
int main()
{
   char ch;
   int n=0,key1=0;
   init();
   prin(1);
   while (1)
   {
   prin(1);
   ch=getch();
   key1=ch;
   n=cursor(ch);
   if (n==2) {clrscr();return 0;}
   if (n==0)
   n=ctrkey(ch);
   if ((key1>=32)&&(key1<=126))
   n=key(ch);
   }
   return 0;
}
