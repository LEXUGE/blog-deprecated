#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
char a[102][102];
int wid=0,turn=0,out=0,ny=0,aiturn=3,aix=0,aiy=0;

void clrscr();

int read_file()
{
  int r=0,i=0,j=0,wid_old=0,aiturn_old=0,turn_old=0;
  char fpath[101]={0};
  char ch=0;
  FILE *fp;
  clrscr();
  printf("[OPEN] Please input the path of the file:\n");
  scanf("%s",fpath);
  getchar();
  if ((fp=fopen(fpath,"r"))==NULL)
  {
    printf("[OPEN] ERROR! Can't open the file!\n");
    getchar();
    clrscr();
    return -1;
  }
  else
  {
    wid_old=wid;
    r=fscanf(fp,"%d",&wid);
    if ((wid<3)||(r!=1)||(wid>100)) {printf("[OPEN] Digital ERROR!\n");wid=wid_old;getchar();clrscr();return -2;}
    r=0;
    while((ch=fgetc(fp))!='\n'&&ch!=EOF);

    aiturn_old=aiturn;
    r=fscanf(fp,"%d",&aiturn);
    if (((aiturn!=0)&&(aiturn!=1)&&(aiturn!=3))||(r!=1)) {printf("[OPEN] Digital ERROR!\n");wid=wid_old;aiturn=aiturn_old;getchar();clrscr();return -2;}
    r=0;
    while((ch=fgetc(fp))!='\n'&&ch!=EOF);

    turn_old=turn;
    r=fscanf(fp,"%d",&turn);
    if (((turn!=0)&&(turn!=1))||(r!=1)||(aiturn==turn)) {printf("[OPEN] Digital ERROR!\n");wid=wid_old;aiturn=aiturn_old;turn=turn_old;getchar();clrscr();return -2;}
    r=0;
    while((ch=fgetc(fp))!='\n'&&ch!=EOF);

    for (i=1;i<=wid;i++)
    {
      for (j=1;j<=wid;j++)
        a[i][j]=fgetc(fp);
      fgetc(fp);
    }
    fclose(fp);
  }
  clrscr();
  return 0;
}

int write_file()
{
  int i=0,j=0;
  char fpath[101]={0};
  FILE *fp;
  clrscr();
  printf("[SAVE] Please input the path of the file:\n");
  scanf("%s",fpath);
  getchar();
  if ((fp=fopen(fpath,"w"))==NULL)
  {
    printf("[SAVE] ERROR! Can't open the file!\n");
    getchar();
    clrscr();
    return -1;
  }
  else
  {
    fprintf(fp,"%d\n",wid);
    fprintf(fp,"%d\n",aiturn);
    fprintf(fp,"%d\n",turn);
    for (i=1;i<=wid;i++)
    {
      for (j=1;j<=wid;j++)
        fprintf(fp,"%c",a[i][j]);
      fprintf(fp,"\n");
    }
    fclose(fp);
  }
  clrscr();
  return 0;
}

void clrscr()
{
  printf("\033c");
}

void display(int n);

int aifight(int x1,int y1)
{
  int sum=0;
  if (aiturn==0)
  {
	if (a[x1-1][y1-1]=='O') sum++;
	if (a[x1-1][y1]=='O') sum++;
	if (a[x1-1][y1+1]=='O') sum++;
	if (a[x1][y1-1]=='O') sum++;
	if (a[x1][y1+1]=='O') sum++;
	if (a[x1+1][y1-1]=='O') sum++;
	if (a[x1+1][y1]=='O') sum++;
	if (a[x1+1][y1+1]=='O') sum++;
  }
  else
  {
	if (a[x1-1][y1-1]=='X') sum++;
	if (a[x1-1][y1]=='X') sum++;
	if (a[x1-1][y1+1]=='X') sum++;
	if (a[x1][y1-1]=='X') sum++;
	if (a[x1][y1+1]=='X') sum++;
	if (a[x1+1][y1-1]=='X') sum++;
	if (a[x1+1][y1]=='X') sum++;
	if (a[x1+1][y1+1]=='X') sum++;
  }
  return sum;
}

void ai()
{
  int i=0,j=0,sum=0,max=-1,max_x=0,max_y=0;
  if (aiturn==0)
  for (i=1;i<=wid;i++)
	for (j=1;j<=wid;j++)
	{
	  if (a[i][j]=='X')
    {
      if (a[i-1][j]==' ') {sum=aifight(i-1,j);if (sum>max) {max=sum;max_x=i-1;max_y=j;}}
      if (a[i+1][j]==' ') {sum=aifight(i+1,j);if (sum>max) {max=sum;max_x=i+1;max_y=j;}}
      if (a[i][j-1]==' ') {sum=aifight(i,j-1);if (sum>max) {max=sum;max_x=i;max_y=j-1;}}
      if (a[i][j+1]==' ') {sum=aifight(i,j+1);if (sum>max) {max=sum;max_x=i;max_y=j+1;}}
    }
	}
  if (aiturn==1)
  for (i=1;i<=wid;i++)
	for (j=1;j<=wid;j++)
	{
	  if (a[i][j]=='O')
    {
      if (a[i-1][j]==' ') {sum=aifight(i-1,j);if (sum>max) {max=sum;max_x=i-1;max_y=j;}}
      if (a[i+1][j]==' ') {sum=aifight(i+1,j);if (sum>max) {max=sum;max_x=i+1;max_y=j;}}
      if (a[i][j-1]==' ') {sum=aifight(i,j-1);if (sum>max) {max=sum;max_x=i;max_y=j-1;}}
      if (a[i][j+1]==' ') {sum=aifight(i,j+1);if (sum>max) {max=sum;max_x=i;max_y=j+1;}}
    }
	}
  aix=max_x;
  aiy=max_y;
}

int scan()
{
  int t1=0,t2=0;
  int i=0,j=0,o=0,x=0;
  for (i=1;i<=wid;i++)
	for (j=1;j<=wid;j++)
	{
	  if (a[i][j]=='X')
    {
      if (a[i-1][j]==' ') t1=1;
      if (a[i+1][j]==' ') t1=1;
      if (a[i][j-1]==' ') t1=1;
      if (a[i][j+1]==' ') t1=1;
      x++;
    }
    if (a[i][j]=='O')
    {
      if (a[i-1][j]==' ') t2=1;
      if (a[i+1][j]==' ') t2=1;
      if (a[i][j-1]==' ') t2=1;
      if (a[i][j+1]==' ') t2=1;
      o++;
    }
	}
  if ((t1==1)&&(t2==1)) return 0;
  if ((t1==0)&&(t2==1))
  {
    o=wid*wid-x;
    clrscr();
    display(wid);
    if (x>o) printf("X is winner!(press any key to continue)\n");
    if (x<o) printf("O is winner!(press any key to continue)\n");
    if (x==o) printf("tie!(press any key to continue)\n");
    return 1;
  }
  if ((t1==1)&&(t2==0))
  {
    x=wid*wid-o;
    clrscr();
    display(wid);
    if (x>o) printf("X is winner!(press any key to continue)\n");
    if (x<o) printf("O is winner!(press any key to continue)\n");
    if (x==o) printf("tie!(press any key to continue)\n");
    return 1;
  }
  if ((t1==0)&&(t2==0))
  {
    clrscr();
    display(wid);
    if (x>o) printf("X is winner!(press any key to continue)\n");
    if (x<o) printf("O is winner!(press any key to continue)\n");
    if (x==o) printf("tie!(press any key to continue)\n");
    return 1;
  }
  return 0;
}
void fight(int x1,int y1)
{
  if (turn==0)
  {
	if (a[x1-1][y1-1]=='O') a[x1-1][y1-1]='X';
	if (a[x1-1][y1]=='O') a[x1-1][y1]='X';
	if (a[x1-1][y1+1]=='O') a[x1-1][y1+1]='X';
	if (a[x1][y1-1]=='O') a[x1][y1-1]='X';
	if (a[x1][y1+1]=='O') a[x1][y1+1]='X';
	if (a[x1+1][y1-1]=='O') a[x1+1][y1-1]='X';
	if (a[x1+1][y1]=='O') a[x1+1][y1]='X';
	if (a[x1+1][y1+1]=='O') a[x1+1][y1+1]='X';
  }
  else
  {
	if (a[x1-1][y1-1]=='X') a[x1-1][y1-1]='O';
	if (a[x1-1][y1]=='X') a[x1-1][y1]='O';
	if (a[x1-1][y1+1]=='X') a[x1-1][y1+1]='O';
	if (a[x1][y1-1]=='X') a[x1][y1-1]='O';
	if (a[x1][y1+1]=='X') a[x1][y1+1]='O';
	if (a[x1+1][y1-1]=='X') a[x1+1][y1-1]='O';
	if (a[x1+1][y1]=='X') a[x1+1][y1]='O';
	if (a[x1+1][y1+1]=='X') a[x1+1][y1+1]='O';
  }
}
void display(int n)
{
  int i=0,j=0;
  clrscr();
  printf("\n");
  for (i=1;i<=n+1;i++)
  {
	if ((i==1)||(i==n+1))
	{
	  if (i==1) printf("%c%c%c%c",'=','=','=','=');
	  if (i==n+1) printf("%c  ",'=');
	}
	else printf("%c%c%c%c",'=','=','=','=');
  }
  printf("\n");
  for (i=1;i<=n*2-1;i++)
  {
	for (j=1;j<=n+1;j++)
	{
	  if (i%2==0)
	  {
		if ((j==1)||(j==n+1))
		{
		  if (j==1) printf("%c%c%c%c",'=','=','=','=');
		  if (j==n+1) printf("%c",'=');
		} else
		printf("%c%c%c%c",'=','=','=','=');
	  }
	  else
	  {
		if (j==n+1) printf("%c",'|'); else
		printf("%c %c ",'|',a[(i+1)/2][j]);
	  }
	}
	printf("\n");
  }
  for (i=1;i<=n+1;i++)
  {
	if ((i==1)||(i==n+1))
	{
	  if (i==1) printf("%c%c%c%c",'=','=','=','=');
	  if (i==n+1) printf("%c  ",'=');
	}
	else printf("%c%c%c%c",'=','=','=','=');
  }
  printf("\n");
}
void game()
{
  char ch;
  int x=0,y=0,t=0;
  while (1)
  {
        x=-5;
        y=-5;
	clrscr();
	display(wid);
	if (turn==0) printf("Now is X\n");
	else printf("Now is O\n");
  if (turn!=aiturn)
  {
	printf("please input two numbers of x,y:");
        scanf("%d %d",&x,&y);
        while((ch=getchar())!='\n'&&ch!=EOF);
  }
  else
  {
    printf("AI!\n");ai();x=aix;y=aiy;
    printf("AI's x=%d y=%d\n",aix,aiy);
    printf("Input any key to continue\n");
    getchar();
    while((ch=getchar())!='\n'&&ch!=EOF);
  }
	if ((x==0)&&(y==0)) {if ((turn+1)%2==0) turn=0; else turn=1;return;}
  if ((x==-1)&&(y==-1)) {read_file();return;}
  if ((x==-2)&&(y==-2)) {write_file();return;}
	if ((x==-3)&&(y==-3)) {out=1;return;}
	if ((a[x][y]==' ')&&((x>=1)&&(x<=wid))&&((y>=1)&&(y<=wid)))
	{
	  if ((turn==0)&&((a[x-1][y]=='X')||(a[x][y-1]=='X')||(a[x][y+1]=='X')||(a[x+1][y]=='X'))) {t=1;a[x][y]='X';fight(x,y);}
	  if ((turn==1)&&((a[x-1][y]=='O')||(a[x][y-1]=='O')||(a[x][y+1]=='O')||(a[x+1][y]=='O'))) {t=1;a[x][y]='O';fight(x,y);}
	  if (t==1) break;
	}
  }
  if (scan()==1) {out=1;return;}
  if ((turn+1)%2==0) turn=0;
  else turn=1;
}
void reset(int x)
{
  int i=0,j=0;
  for (i=1;i<=x;i++)
	for (j=1;j<=x;j++)
	  a[i][j]=' ';
  a[1][1]='O';
  a[1][x]='O';
  a[x][1]='X';
  a[x][x]='X';
  i=0;j=0;
  for (i=0;i<=101;i++)
  {
    if ((i==0)||(i==101))
      for (j=0;j<=101;j++) a[i][j]=3;
    else {a[i][0]=3;a[i][101]=3;}
  }
}
void start()
{
  int r=0;
  char ch;

  printf("GAMEOX\n");
  printf("Copyright (2015-2017) LEXUGE\n");
  printf("The software is using GPL(http://www.gnu.org/licenses/gpl.txt)\n");
  getchar();
  while((ch=getchar())!='\n'&&ch!=EOF);
  clrscr();

  printf("Please input a number of width:");
  r=scanf("%d",&wid);
  if ((wid<3)||(r!=1)||(wid>100)) {printf("input again!\n");return;}
  r=0;
  while((ch=getchar())!='\n'&&ch!=EOF);
  reset(wid);
  clrscr();

  printf("Please input a number of first player(0:X/1:O):");
  r=scanf("%d",&turn);
  if (((turn!=0)&&(turn!=1))||(r!=1)) {printf("input again!\n");return;}
  r=0;
  while((ch=getchar())!='\n'&&ch!=EOF);
  clrscr();

  printf("Do you want to play with AI?(0:No/1:Yes):");
  r=scanf("%d",&ny);
  if (((ny!=0)&&(ny!=1))||(r!=1)) {printf("input again!\n");return;}
  r=0;
  while((ch=getchar())!='\n'&&ch!=EOF);
  if (ny==1) {aiturn=1-turn;}
  display(wid);

  while (1)
  {
	  game();
	  if (out==1) break;
  }
}
int main()
{
  clrscr();
  start();
  return 0;
}
